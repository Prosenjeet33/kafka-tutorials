cat configuration/ccloud.properties >> configuration/dev.properties
