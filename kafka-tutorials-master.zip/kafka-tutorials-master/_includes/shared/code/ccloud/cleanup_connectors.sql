DROP CONNECTOR IF EXISTS <connector_name>;
