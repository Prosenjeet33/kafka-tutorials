./gradlew shadowJar
