mkdir aggregating-average && cd aggregating-average
