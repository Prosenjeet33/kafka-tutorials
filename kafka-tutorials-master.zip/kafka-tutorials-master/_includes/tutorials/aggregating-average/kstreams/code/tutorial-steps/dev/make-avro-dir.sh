mkdir -p src/main/avro
