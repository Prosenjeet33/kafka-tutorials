gradle jibDockerBuild --image=io.confluent.developer/aggregating-average:0.0.1
