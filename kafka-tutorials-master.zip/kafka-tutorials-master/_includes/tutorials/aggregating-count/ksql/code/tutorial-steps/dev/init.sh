mkdir aggregate-count && cd aggregate-count
