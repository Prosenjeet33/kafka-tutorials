SET 'ksql.streams.cache.max.bytes.buffering' = '10000000';
