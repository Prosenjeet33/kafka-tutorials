SET 'auto.offset.reset' = 'earliest';
