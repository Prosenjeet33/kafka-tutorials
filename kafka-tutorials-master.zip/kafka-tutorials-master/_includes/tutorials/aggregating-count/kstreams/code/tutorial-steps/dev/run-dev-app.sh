java -jar build/libs/kstreams-aggregating-count-standalone-0.0.1.jar configuration/dev.properties
