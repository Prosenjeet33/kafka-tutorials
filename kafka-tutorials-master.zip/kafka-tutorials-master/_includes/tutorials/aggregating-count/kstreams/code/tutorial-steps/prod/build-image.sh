gradle jibDockerBuild --image=io.confluent.developer/kstreams-aggregating-count:0.0.1
