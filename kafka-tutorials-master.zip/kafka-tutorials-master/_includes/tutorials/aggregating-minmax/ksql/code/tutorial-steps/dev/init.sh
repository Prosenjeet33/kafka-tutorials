mkdir aggregate-minmax && cd aggregate-minmax
