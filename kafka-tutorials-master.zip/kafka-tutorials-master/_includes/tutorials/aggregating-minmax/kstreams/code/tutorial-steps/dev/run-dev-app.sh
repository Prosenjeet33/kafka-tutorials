java -jar build/libs/kstreams-aggregating-minmax-standalone-0.0.1.jar configuration/dev.properties
