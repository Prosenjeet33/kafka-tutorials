gradle jibDockerBuild --image=io.confluent.developer/kstreams-aggregating-minmax:0.0.1
