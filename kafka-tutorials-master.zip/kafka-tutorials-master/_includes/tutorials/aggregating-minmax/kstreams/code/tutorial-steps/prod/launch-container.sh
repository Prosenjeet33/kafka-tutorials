docker run -v $PWD/configuration/prod.properties:/config.properties io.confluent.developer/kstreams-aggregating-minmax:0.0.1 config.properties
