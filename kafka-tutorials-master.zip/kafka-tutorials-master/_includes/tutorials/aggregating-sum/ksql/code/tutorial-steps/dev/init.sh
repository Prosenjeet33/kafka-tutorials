mkdir aggregate-sum && cd aggregate-sum
