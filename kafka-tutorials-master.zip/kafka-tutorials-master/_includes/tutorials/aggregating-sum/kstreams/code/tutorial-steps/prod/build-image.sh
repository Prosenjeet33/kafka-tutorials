gradle jibDockerBuild --image=io.confluent.developer/kstreams-aggregating-sum:0.0.1
