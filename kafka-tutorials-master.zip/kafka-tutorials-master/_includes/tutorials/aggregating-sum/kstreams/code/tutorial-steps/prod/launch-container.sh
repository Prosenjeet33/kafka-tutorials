docker run -v $PWD/configuration/prod.properties:/config.properties io.confluent.developer/kstreams-aggregating-sum:0.0.1 config.properties
