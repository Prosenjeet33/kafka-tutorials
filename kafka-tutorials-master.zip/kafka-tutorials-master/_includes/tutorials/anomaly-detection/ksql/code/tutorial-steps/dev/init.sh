mkdir anomaly-detection && cd anomaly-detection
