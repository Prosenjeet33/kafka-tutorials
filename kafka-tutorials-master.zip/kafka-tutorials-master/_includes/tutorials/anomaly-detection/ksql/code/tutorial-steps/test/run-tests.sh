docker exec ksqldb-cli ksql-test-runner -s /opt/app/src/test-statements.sql -o /opt/app/test/output.json
