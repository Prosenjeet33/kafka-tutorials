SELECT * FROM customer_flight_updates EMIT CHANGES LIMIT 3;
