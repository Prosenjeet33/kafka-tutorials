SELECT * FROM contributions_small_count;
