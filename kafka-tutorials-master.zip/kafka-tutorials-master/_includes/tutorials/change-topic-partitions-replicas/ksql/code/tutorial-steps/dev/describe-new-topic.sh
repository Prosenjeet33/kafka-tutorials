docker-compose exec broker kafka-topics --bootstrap-server broker:9092 --topic topic2 --describe
