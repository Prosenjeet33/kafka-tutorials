mkdir change-topic-partitions-replicas && cd change-topic-partitions-replicas
