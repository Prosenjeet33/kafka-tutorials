confluent kafka topic consume output-topic -b --value-format avro
