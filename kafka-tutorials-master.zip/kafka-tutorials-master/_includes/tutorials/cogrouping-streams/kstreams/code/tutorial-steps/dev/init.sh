mkdir cogrouping-streams && cd cogrouping-streams
