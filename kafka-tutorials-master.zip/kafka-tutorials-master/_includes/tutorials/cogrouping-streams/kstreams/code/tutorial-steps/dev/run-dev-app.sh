java -jar build/libs/cogrouping-streams-standalone-0.0.1.jar configuration/dev.properties
