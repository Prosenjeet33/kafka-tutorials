gradle jibDockerBuild --image=io.confluent.developer/cogrouping-streams-join:0.0.1
