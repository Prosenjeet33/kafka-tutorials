docker run -v $PWD/configuration/prod.properties:/config.properties io.confluent.developer/cogrouping-streams-join:0.0.1 config.properties
